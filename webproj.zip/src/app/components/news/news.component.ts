import {Component, ElementRef, HostListener} from '@angular/core';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent {
  viewMode = 'otherwise';
}
